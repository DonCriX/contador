import * as React from 'react';
import { useState, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import imageCompression from 'browser-image-compression';

interface ImageUploaderProps {
  className?: string;
}

export function ImageUploader({ className }: ImageUploaderProps) {
  const [originalImage, setOriginalImage] = useState<File | null>(null);
  const [originalPreview, setOriginalPreview] = useState<string | null>(null);
  const [originalSize, setOriginalSize] = useState<number>(0);
  
  const [compressedImage, setCompressedImage] = useState<File | null>(null);
  const [compressedPreview, setCompressedPreview] = useState<string | null>(null);
  const [compressedSize, setCompressedSize] = useState<number>(0);
  
  const [targetSize, setTargetSize] = useState<number>(500); // 500KB default
  const [isCompressing, setIsCompressing] = useState<boolean>(false);
  const [compressionProgress, setCompressionProgress] = useState<number>(0);
  
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUpload = (file: File) => {
    // Reset states
    setCompressedImage(null);
    setCompressedPreview(null);
    setCompressedSize(0);
    setCompressionProgress(0);
    
    // Set original image
    setOriginalImage(file);
    setOriginalSize(file.size / 1024); // Convert to KB
    
    // Generate preview for original image
    const reader = new FileReader();
    reader.onloadend = () => {
      setOriginalPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      handleUpload(files[0]);
    }
  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      const file = files[0];
      if (file.type.startsWith('image/')) {
        handleUpload(file);
      } else {
        alert('Please upload an image file');
      }
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleTargetSizeChange = (value: number[]) => {
    setTargetSize(value[0]);
  };

  const compressImage = async () => {
    if (!originalImage) return;
    
    setIsCompressing(true);
    setCompressionProgress(0);
    
    try {
      const options = {
        maxSizeMB: targetSize / 1024, // Convert KB to MB
        useWebWorker: true,
        onProgress: (progress: number) => {
          setCompressionProgress(progress);
        }
      };
      
      const compressedFile = await imageCompression(originalImage, options);
      setCompressedImage(compressedFile);
      setCompressedSize(compressedFile.size / 1024); // Convert to KB
      
      // Generate preview for compressed image
      const reader = new FileReader();
      reader.onloadend = () => {
        setCompressedPreview(reader.result as string);
      };
      reader.readAsDataURL(compressedFile);
    } catch (error) {
      console.error('Error compressing image:', error);
      alert('Error compressing image. Please try again.');
    } finally {
      setIsCompressing(false);
      setCompressionProgress(100);
    }
  };

  const downloadCompressedImage = () => {
    if (!compressedImage) return;
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(compressedImage);
    link.download = `compressed-${compressedImage.name}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatFileSize = (sizeInKB: number): string => {
    if (sizeInKB < 1024) {
      return `${sizeInKB.toFixed(2)} KB`;
    } else {
      return `${(sizeInKB / 1024).toFixed(2)} MB`;
    }
  };

  return (
    <div className={className}>
      <div className="space-y-6 w-full max-w-3xl mx-auto">
        {/* Upload Area */}
        <div 
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging ? "border-primary bg-primary/10" : "border-border"
          }`}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          <input 
            type="file" 
            accept="image/*" 
            className="hidden" 
            onChange={handleFileChange} 
            ref={fileInputRef}
          />
          
          <div className="flex flex-col items-center justify-center space-y-4">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-12 w-12 text-muted-foreground" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" 
              />
            </svg>
            <h3 className="text-lg font-medium">Drag and drop your image</h3>
            <p className="text-muted-foreground">or</p>
            <Button onClick={handleButtonClick}>Browse Files</Button>
          </div>
        </div>

        {/* Target Size Selector */}
        {originalImage && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-medium">Target Size: {formatFileSize(targetSize)}</h3>
              <span className="text-sm text-muted-foreground">
                Original: {formatFileSize(originalSize)}
              </span>
            </div>
            <Slider 
              defaultValue={[targetSize]} 
              min={50} 
              max={2000} 
              step={50}
              onValueChange={handleTargetSizeChange}
              className="w-full"
            />
            <Button 
              onClick={compressImage} 
              disabled={isCompressing || !originalImage}
              className="w-full"
            >
              {isCompressing ? "Compressing..." : "Compress Image"}
            </Button>
            {isCompressing && <Progress value={compressionProgress} />}
          </div>
        )}

        {/* Image Preview Area */}
        {(originalPreview || compressedPreview) && (
          <div className="space-y-4">
            <h3 className="font-medium">Image Preview</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Original Image */}
              {originalPreview && (
                <div className="space-y-2">
                  <p className="text-sm font-medium">Original</p>
                  <div className="relative aspect-square bg-secondary/50 rounded-md overflow-hidden">
                    <img 
                      src={originalPreview} 
                      alt="Original" 
                      className="absolute inset-0 w-full h-full object-contain"
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Size: {formatFileSize(originalSize)}
                  </p>
                </div>
              )}
              
              {/* Compressed Image */}
              {compressedPreview && (
                <div className="space-y-2">
                  <p className="text-sm font-medium">Compressed</p>
                  <div className="relative aspect-square bg-secondary/50 rounded-md overflow-hidden">
                    <img 
                      src={compressedPreview} 
                      alt="Compressed" 
                      className="absolute inset-0 w-full h-full object-contain"
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Size: {formatFileSize(compressedSize)}
                  </p>
                  <Button 
                    onClick={downloadCompressedImage}
                    className="w-full"
                  >
                    Download Compressed Image
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
