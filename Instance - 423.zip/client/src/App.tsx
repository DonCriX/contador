import * as React from 'react';
import { ImageUploader } from '@/components/ImageUploader';

function App() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-primary mb-2">Image Compressor</h1>
          <p className="text-muted-foreground">
            Upload, compress, and download your images easily
          </p>
        </div>
        <ImageUploader className="mb-8" />
      </div>
    </div>
  );
}

export default App;
